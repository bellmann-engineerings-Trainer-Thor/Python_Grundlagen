# Multiplikation
#
# Schreibe ein Programm, das ermittelt,
# wie viele ganzzahlige Multiplikator-Multiplikand-Kombinationen
# vom Produkt 8.420.000 es gibt,
# bei denen sowohl Multiplikator als auch Multiplikand
# kleiner als 10.000 sind.
#
# 1000*8420 und 8420*1000 ist nur eine Kombination.
