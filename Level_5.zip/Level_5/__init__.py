import meinePrintbefehle
print("import meinePrintbefehle")

meinePrintbefehle.print_red("Hallo")
meinePrintbefehle.print_green("Hallo")
meinePrintbefehle.print_yellow("Hallo")
meinePrintbefehle.print_blue("Hallo")
meinePrintbefehle.print_magenta("Hallo")
meinePrintbefehle.print_cyan("Hallo")
meinePrintbefehle.print_bold("Hallo")

import meinePrintbefehle as p
print("import meinePrintbefehle as p")

p.print_red("Hallo")
p.print_green("Hallo")
p.print_yellow("Hallo")
p.print_blue("Hallo")
p.print_magenta("Hallo")
p.print_cyan("Hallo")
p.print_bold("Hallo")

from meinePrintbefehle import *
print("from meinePrintbefehle import *")
print_red("Hallo")
print_green("Hallo")
print_yellow("Hallo")
print_blue("Hallo")
print_magenta("Hallo")
print_cyan("Hallo")
print_bold("Hallo")