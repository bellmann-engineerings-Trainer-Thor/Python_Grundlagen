
def addiere(arg1, arg2):
    return arg1 + arg2

def subtrahiere(arg1, arg2):
    return arg1 - arg2


meineKonstante = 123456

if __name__ == "__main__":
    print(subtrahiere(1,10))
    print("Hallo")