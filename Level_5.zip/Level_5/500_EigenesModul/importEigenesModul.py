import myMath



var1 = myMath.addiere(1, 2)
print(var1)

var2 = myMath.subtrahiere(10, 2)
print(var2)

print(myMath.meineKonstante)