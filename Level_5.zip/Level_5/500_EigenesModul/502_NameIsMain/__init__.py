from NameIsMain import MeineKlasse


meineKlasse = MeineKlasse
