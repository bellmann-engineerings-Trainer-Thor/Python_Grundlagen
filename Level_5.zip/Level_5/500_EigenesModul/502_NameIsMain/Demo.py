import NameIsMain


objekt = NameIsMain.MeineKlasse()