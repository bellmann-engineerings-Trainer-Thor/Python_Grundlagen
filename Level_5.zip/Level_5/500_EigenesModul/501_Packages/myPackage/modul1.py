def functionAusModul1():
    print("ich bin im Modul1")