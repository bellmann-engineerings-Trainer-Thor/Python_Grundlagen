def functionAusModul3():
    print("ich bin im Modul3 und befinde mich in einem SubPackage")