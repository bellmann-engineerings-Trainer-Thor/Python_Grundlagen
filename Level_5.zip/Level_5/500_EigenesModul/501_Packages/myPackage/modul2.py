def functionAusModul2():
    print("ich bin im Modul2")