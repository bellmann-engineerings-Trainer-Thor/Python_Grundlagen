from myPackage import modul1, modul2
from myPackage.subPackage import modul3

modul1.functionAusModul1()
modul2.functionAusModul2()
modul3.functionAusModul3()